package com.cinema.service;

import com.cinema.model.Movie;
import java.util.ArrayList;
import java.util.List;

/**
 * Servicio para gestionar películas.
 */
public class MovieService {
    private List<Movie> movies = new ArrayList<>();

    public void addMovie(Movie movie) {
        movies.add(movie);
    }

    public List<Movie> getAllMovies() {
        return movies;
    }

    public Movie findMovieById(String id) {
        return movies.stream().filter(m -> m.getId().equals(id)).findFirst().orElse(null);
    }
}

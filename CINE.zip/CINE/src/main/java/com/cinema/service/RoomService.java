  package com.cinema.service;

import com.cinema.model.CinemaRoom;
import java.util.ArrayList;
import java.util.List;

/**
 * Servicio para gestionar salas de cine.
 */
public class RoomService {
    private List<CinemaRoom> rooms = new ArrayList<>();

    public void addRoom(CinemaRoom room) {
        rooms.add(room);
    }

    public List<CinemaRoom> getAllRooms() {
        return rooms;
    }

    public CinemaRoom findRoomByName(String name) {
        return rooms.stream()
                .filter(room -> room.getNombre().equals(name))
                .findFirst()
                .orElse(null);
    }
}

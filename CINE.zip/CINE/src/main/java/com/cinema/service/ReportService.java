package com.cinema.service;

import com.cinema.model.*;
import java.util.List;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

/**
 * Service for generating reports.
 */
public class ReportService {
    public void generateReservationReport(List<Reservation> reservations) {
        System.out.println("Reporte de Reservas:");
        for (Reservation r : reservations) {
            System.out.println(r);
        }
    }

    public void generateTestScriptsPDF(String markdownFilePath, String pdfFilePath) throws IOException {
        // Read the markdown content
        String content = new String(Files.readAllBytes(Paths.get(markdownFilePath)));

        // Create a new PDF document
        PDDocument document = new PDDocument();
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);

        // Create a content stream for the page
        PDPageContentStream contentStream = new PDPageContentStream(document, page);

        // Set font and size
        contentStream.setFont(PDType1Font.HELVETICA, 12);
        contentStream.beginText();
        contentStream.newLineAtOffset(50, 800);

        float yPosition = 800;
        float leading = 15;

        // Add title
        contentStream.showText("REPORTE DEL SISTEMA DE RESERVAS PARA CINE");
        contentStream.newLineAtOffset(0, -leading * 2);
        yPosition -= leading * 2;

        // Split content into lines and add to PDF
        String[] lines = content.split("\n");
        for (String line : lines) {
            // Check if we need a new page
            if (yPosition <= 50) {
                contentStream.endText();
                contentStream.close();
                page = new PDPage(PDRectangle.A4);
                document.addPage(page);
                contentStream = new PDPageContentStream(document, page);
                contentStream.setFont(PDType1Font.HELVETICA, 12);
                contentStream.beginText();
                contentStream.newLineAtOffset(50, 800);
                yPosition = 800;
            }

            // Truncate long lines if necessary
            if (line.length() > 80) {
                line = line.substring(0, 77) + "...";
            }

            contentStream.showText(line);
            contentStream.newLineAtOffset(0, -leading);
            yPosition -= leading;
        }

        contentStream.endText();
        contentStream.close();

        // Save the document
        document.save(pdfFilePath);
        document.close();

        System.out.println("PDF generado: " + pdfFilePath);
    }

    public void generateSystemReportPDF(String pdfFilePath, RoomService roomService, MovieService movieService, ReservationService reservationService) throws IOException {
        // Create a new PDF document
        PDDocument document = new PDDocument();
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);

        // Create a content stream for the page
        PDPageContentStream contentStream = new PDPageContentStream(document, page);

        // Set font and size
        contentStream.setFont(PDType1Font.HELVETICA, 12);
        contentStream.beginText();
        contentStream.newLineAtOffset(50, 800);

        float yPosition = 800;
        float leading = 15;

        // Add title
        contentStream.showText("REPORTE DEL SISTEMA DE RESERVAS PARA CINE");
        contentStream.newLineAtOffset(0, -leading * 2);
        yPosition -= leading * 2;

        // Add date
        contentStream.showText("Fecha de generacion: " + java.time.LocalDate.now());
        contentStream.newLineAtOffset(0, -leading);
        yPosition -= leading;

        contentStream.newLineAtOffset(0, -leading);
        yPosition -= leading;

        // Rooms section
        contentStream.showText("SALAS REGISTRADAS:");
        contentStream.newLineAtOffset(0, -leading);
        yPosition -= leading;

        List<CinemaRoom> rooms = roomService.getAllRooms();
        if (rooms.isEmpty()) {
            contentStream.showText("No hay salas registradas.");
            contentStream.newLineAtOffset(0, -leading);
            yPosition -= leading;
        } else {
            for (CinemaRoom room : rooms) {
                if (yPosition <= 50) {
                    contentStream.endText();
                    contentStream.close();
                    page = new PDPage(PDRectangle.A4);
                    document.addPage(page);
                    contentStream = new PDPageContentStream(document, page);
                    contentStream.setFont(PDType1Font.HELVETICA, 12);
                    contentStream.beginText();
                    contentStream.newLineAtOffset(50, 800);
                    yPosition = 800;
                }
                contentStream.showText("- Nombre: " + room.getNombre() + ", Capacidad: " + room.getCapacidad());
                contentStream.newLineAtOffset(0, -leading);
                yPosition -= leading;
            }
        }

        contentStream.newLineAtOffset(0, -leading);
        yPosition -= leading;

        // Movies section
        contentStream.showText("PELICULAS REGISTRADAS:");
        contentStream.newLineAtOffset(0, -leading);
        yPosition -= leading;

        List<Movie> movies = movieService.getAllMovies();
        if (movies.isEmpty()) {
            contentStream.showText("No hay peliculas registradas.");
            contentStream.newLineAtOffset(0, -leading);
            yPosition -= leading;
        } else {
            for (Movie movie : movies) {
                if (yPosition <= 50) {
                    contentStream.endText();
                    contentStream.close();
                    page = new PDPage(PDRectangle.A4);
                    document.addPage(page);
                    contentStream = new PDPageContentStream(document, page);
                    contentStream.setFont(PDType1Font.HELVETICA, 12);
                    contentStream.beginText();
                    contentStream.newLineAtOffset(50, 800);
                    yPosition = 800;
                }
                contentStream.showText("- ID: " + movie.getId() + ", Titulo: " + movie.getTitulo() + ", Duracion: " + movie.getDuracion() + " min");
                contentStream.newLineAtOffset(0, -leading);
                yPosition -= leading;
            }
        }

        contentStream.newLineAtOffset(0, -leading);
        yPosition -= leading;

        // Reservations section
        contentStream.showText("RESERVAS REGISTRADAS:");
        contentStream.newLineAtOffset(0, -leading);
        yPosition -= leading;

        List<Reservation> reservations = reservationService.getAllReservations();
        if (reservations.isEmpty()) {
            contentStream.showText("No hay reservas registradas.");
            contentStream.newLineAtOffset(0, -leading);
            yPosition -= leading;
        } else {
            for (Reservation reservation : reservations) {
                if (yPosition <= 50) {
                    contentStream.endText();
                    contentStream.close();
                    page = new PDPage(PDRectangle.A4);
                    document.addPage(page);
                    contentStream = new PDPageContentStream(document, page);
                    contentStream.setFont(PDType1Font.HELVETICA, 12);
                    contentStream.beginText();
                    contentStream.newLineAtOffset(50, 800);
                    yPosition = 800;
                }
                contentStream.showText("- ID: " + reservation.getId() + ", Cliente: " + reservation.getCliente().getNombre() + ", Estado: " + reservation.getEstado().toString());
                contentStream.newLineAtOffset(0, -leading);
                yPosition -= leading;
            }
        }

        contentStream.endText();
        contentStream.close();

        // Save the document
        document.save(pdfFilePath);
        document.close();

        System.out.println("PDF del sistema generado: " + pdfFilePath);
    }
}

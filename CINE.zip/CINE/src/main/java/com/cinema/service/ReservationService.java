package com.cinema.service;

import com.cinema.model.Reservation;
import java.util.ArrayList;
import java.util.List;

/**
 * Servicio para gestionar reservas.
 */
public class ReservationService {
    private List<Reservation> reservations = new ArrayList<>();

    public void addReservation(Reservation reservation) {
        reservations.add(reservation);
    }

    public List<Reservation> getAllReservations() {
        return reservations;
    }

    public Reservation findReservationById(String id) {
        return reservations.stream().filter(r -> r.getId().equals(id)).findFirst().orElse(null);
    }
}
